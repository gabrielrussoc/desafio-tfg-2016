Olá!

Alguns esclarecimentos sobre o desafio:

- Algumas das exigências não foram cumpridas, como por exemplo a das animações
(tanto das colisões quando dos pneus girando).

- A velocidade aumenta de forma proporcional ao log natural do tempo decorrido.

- O código praticamente não tem documentação e está longe de ser claro/bonito.

- Para evitar obstáculos impossíveis, evitei que existisse uma 'corrente' de
obstáculos que ligasse uma extremidade a outra.

- Inimigos surgem aleatoriamente (4%) a cada game loop, sendo eles:
    - Outros carros (70%)
    - Buracos (15%)
    - Óleo (15%)

- A arte vem tanto do software GIMP quanto de: http://opengameart.org/

Gostaria de agradecer a TFG pela oportunidade e dizer que aprendi e me diverti fazendo
o desafio. Minha previsão de formatura é Dez/2018 (estou no segundo ano de ciência
da computação).

Gabriel de Russo e Carmo
gabrielrcarmo@gmail.com
